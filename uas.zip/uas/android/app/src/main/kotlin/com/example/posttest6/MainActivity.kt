package com.example.posttest6

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
